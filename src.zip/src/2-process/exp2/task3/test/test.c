#include <stdio.h>
int main() {
	while(1) getchar();
	return 0;
}
