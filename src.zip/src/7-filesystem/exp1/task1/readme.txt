# make
# ./my_shell
/ls
total:0
name    type    size    FCB     dataStartBlock
......
/exit
# make clean