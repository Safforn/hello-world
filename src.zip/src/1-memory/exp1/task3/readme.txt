# make
# ./test
arrays [0][0] is OK.
......
arrays [49][49] is OK.
# make clean
